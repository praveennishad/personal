module.exports = {
    db: 'mongodb://localhost/meand',
    sessionSecret: 'developmentSessionSecret',
    facebook: {    clientID: 'FACEBOOK_APP_ID',    clientSecret: 'FACEBOOK_APP_SECRET',    callbackURL: 'http://localhost:3000/oauth/facebook/callback'  } 
   };